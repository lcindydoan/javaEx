/*
 * Java Swing Compound Interest Example
 * Author: Cindy Doan
 * 05/19/2021
 */
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import javax.swing.*;

public class CI extends JFrame implements ActionListener {

    JFrame frm;
    JLabel lab1;
    JButton Calculate = new JButton("Calculate");
    JButton backButton;
    JPanel panel;
    JComboBox<String> box;
    JComboBox<String> box2;
    JLabel principalLabel = new JLabel(" Principal (Beginning Balance): $ ");
    JLabel rateLabel = new JLabel(" Annual Percentage Rate: % ");
    JLabel compIntervalLabel = new JLabel(" Your Compounding Interval: ");
    JLabel box2Label = new JLabel(" Number of ");
    JLabel daysLabel = new JLabel(" to grow: ");
    JLabel accruLabel = new JLabel(" Accrued Balance: $ ");
    JTextField balanceText = new JTextField("1000.00");
    JTextField rateText = new JTextField("12.00");
    JTextField daysText = new JTextField("1");
    JTextField accruedAmtText = new JTextField("");
    NumberFormat formatter = new DecimalFormat("#0.00");
    DecimalFormat dc = new DecimalFormat("0.00");

    public void plainWindow() {
        frm = new JFrame("Compound Interest Calculator");
        panel = new JPanel(null);
        frm.add(panel);
        lab1 = new JLabel("Compound Interest Calculator");
        lab1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 24));
        lab1.setForeground(Color.BLUE);
        lab1.setHorizontalAlignment(JLabel.CENTER);
        lab1.setSize(400, 100);
        lab1.setBounds(0, 28, 380, 30);
        principalLabel.setBounds(30, 80, 220, 30);
        principalLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        balanceText.setBounds(240, 80, 110, 30);
        rateLabel.setBounds(30, 120, 220, 30);
        rateLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        rateText.setBounds(240, 120, 110, 30);
        compIntervalLabel.setBounds(30, 160, 220, 30);
        compIntervalLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        daysLabel.setBounds(200, 200, 150, 30);
        daysLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        daysText.setBounds(290, 200, 60, 30);
        accruLabel.setBounds(80, 250, 150, 30);
        accruLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        accruedAmtText.setBounds(220, 250, 130, 30);
        Calculate.setBounds(230, 310, 100, 30);
        Calculate.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        Calculate.setForeground(Color.RED);
        backButton = new JButton("To Main");
        backButton.setFont(new Font("Microsoft YaHei UI", Font.BOLD | Font.ITALIC, 12));
        backButton.setBounds(60, 330, 90, 30);
        backButton.setForeground(Color.GRAY);
        String subjects[] = {"Daily", "Monthly", "Quarterly", "Annually"};
        box = new JComboBox<>(subjects);
        box.setBounds(240, 160, 110, 30);
        box2Label.setBounds(30, 200, 220, 30);
        box2Label.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        String subjects2[] = {"Days", "Months", "Years"};
        box2 = new JComboBox<>(subjects2);
        box2.setBounds(110, 200, 80, 30);

        Calculate.addActionListener(this);        

        panel.add(lab1);
        panel.add(Calculate);
        panel.add(box);
        panel.add(box2);
        panel.add(backButton);
        panel.add(principalLabel);
        panel.add(balanceText);
        panel.add(rateLabel);
        panel.add(rateText);
        panel.add(compIntervalLabel);
        panel.add(compIntervalLabel);
        panel.add(box2Label);
        panel.add(daysLabel);
        panel.add(daysText);
        panel.add(accruLabel);
        panel.add(accruedAmtText);

        frm.setSize(410, 460);
        frm.setLocationRelativeTo(null);
        frm.setVisible(true);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                Menu frame = new Menu();
                frame.mainWindow();
                frm.setVisible(false);
            }
        });       
    }

    public void actionPerformed(ActionEvent e) {
        // String response = "Your Choice: "+ box.getSelectedItem().toString()+ box2.getSelectedItem().toString();
        // lab1.setText(response);
        // daily interest : (principal * (rate/100) / 365) * number;
        // time: 1/365 = (0.00273972602739726027397260273973)

        //    balanceText.setText(Log.checkingAmount1);
        double principal = 0;
        double rate = 0;
        double time = 0;
        double number = 0;
        double n = 0;
        double t = 0;
        principal = Double.parseDouble(balanceText.getText());
        rate = Double.parseDouble(rateText.getText());
        String response1 = box.getSelectedItem().toString();
        String response2 = box2.getSelectedItem().toString();
        time = Double.parseDouble(daysText.getText());
        if (response1.equals("Daily") && response2.equals("Days")) {
            number = 360;
            t = (0.00277777777777777777777777777778)*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Daily") && response2.equals("Months")) {
            number = 360;
            t = (0.00277777777777777777777777777778)*30*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Daily") && response2.equals("Years")) {
            number = 360;
            t = (0.00277777777777777777777777777778)*30*12*time;
          lab1.setText(response1+response2);
        }
        
        
        if (response1.equals("Monthly") && response2.equals("Days")) {
            number = 12;
            t = (0.00277777777777777777777777777778)*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Monthly") && response2.equals("Months")) {
            number = 12;
            t = (0.00277777777777777777777777777778)*30*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Monthly") && response2.equals("Years")) {
            number = 12;
            t = (0.00277777777777777777777777777778)*30*12*time;
          lab1.setText(response1+response2);
        }
        
        if (response1.equals("Quarterly") && response2.equals("Days")) {
            number = 4;
            t = (0.00277777777777777777777777777778)*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Quarterly") && response2.equals("Months")) {
            number = 4;
            t = (0.00277777777777777777777777777778)*30*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Quarterly") && response2.equals("Years")) {
            number = 4;
            t = (0.00277777777777777777777777777778)*30*12*time;
          lab1.setText(response1+response2);
        }
        
        if (response1.equals("Annually") && response2.equals("Days")) {
            number = 1;
            t = (0.00277777777777777777777777777778)*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Annually") && response2.equals("Months")) {
            number = 1;
            t = (0.00277777777777777777777777777778)*30*time;
          lab1.setText(response1+response2);
        }
        if (response1.equals("Annually") && response2.equals("Years")) {
            number = 1;
            t = (0.00277777777777777777777777777778)*30*12*time;
          lab1.setText(response1+response2);
        }
        
        
        
        double A = principal * (Math.pow((1 + ((rate / 100) / number)), (t * number)));
        String formaAccru = dc.format(A);
        accruedAmtText.setText(formaAccru);

    }

    public static void main(String[] args) {
        
        EventQueue.invokeLater(new Runnable() {
            public void run() {                
                try {                  
                    CI frame = new CI();                    
                    frame.plainWindow();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        
    }
}

/*
 * Java Swing Compound Interest Example
 * Author: Cindy Doan
 * 05/19/2021
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Scanner;

class Record {
    Scanner scan;
    static String checkingDate1, checkingAmount1, checkingRate1, checkingEarnings1,
            savingsDate1, savingsAmount1, savingsRate1, savingsEarnings1,
            firstWord1, firstBal1, firstRate1, firstEarnings1, firstWord2, firstBal2, firstRate2, firstEarnings2;

    NumberFormat formatter = new DecimalFormat("#0.00");

    public static void writeFile(String filename, String value1, String value2, String value3, String value4) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter pw = null;
        Date date = new Date();
        long time = date.getTime();
        Timestamp ts = new Timestamp(time);
        try {
            fw = new FileWriter(filename, true);
            bw = new BufferedWriter(fw);
            pw = new PrintWriter(bw);          
            pw.println("Date:    " + " Balance: " + "Rate: " + "Earnings:   ");
            pw.println((value1) + "" + (value2) + "" + (value3) + "" + (value4) + "");
            System.out.println("Data Successfully appended into file");
            pw.flush();
        } // print error message if there is one
        catch (IOException io) {
            System.out.println("File IO Exception" + io.getMessage());
        } //close the file
        finally {
            try {
                pw.close();
                bw.close();
                fw.close();
            } //print error message if there is one
            catch (IOException io) {
                System.out.println("Issue closing the File." + io.getMessage());
            }
        }
    }

    public static void lastDateCalc1() {
       BufferedReader inputStream = null;
        try {
            File file = new File("checking1.txt");
            InputStreamReader streamReader
                    = new InputStreamReader(new FileInputStream(file));
            BufferedReader br = new BufferedReader(streamReader);
            String line = new String();
            while (br.ready()) {
                line = br.readLine();
                String mystring = line;
                String arr[] = mystring.split(" ", 4);
                firstWord1 = arr[0];   
                firstBal1 = arr[1];
                firstRate1 = arr[2];
                firstEarnings1 = arr[3];
            }
        } catch (IOException io) {
            System.out.println("File IO exception" + io.getMessage());
        } finally {                    
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException io) {
                System.out.println("Issue closing the Files" + io.getMessage());
            }
        }
    }
    
    public static void lastDateCalc2() {
       BufferedReader inputStream = null;
        try {
            File file = new File("savings1.txt");
            InputStreamReader streamReader
                    = new InputStreamReader(new FileInputStream(file));
            BufferedReader br = new BufferedReader(streamReader);
            String line = new String();
            while (br.ready()) {
                line = br.readLine();
                String mystring = line;
                String arr[] = mystring.split(" ", 4);
                firstWord2 = arr[0];   
                firstBal2 = arr[1];
                firstRate2 = arr[2];
                firstEarnings2 = arr[3];
            }
        } catch (IOException io) {
            System.out.println("File IO exception" + io.getMessage());
        } finally {                    
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException io) {
                System.out.println("Issue closing the Files" + io.getMessage());
            }
        }
    }

   

    public static void lastAccessed() {        
        BufferedReader inputStream = null;
        try {
            File file = new File("checking1.txt");
            InputStreamReader streamReader
                    = new InputStreamReader(new FileInputStream(file));
            BufferedReader br = new BufferedReader(streamReader);
            String line = new String();
            while (br.ready()) {
                line = br.readLine();
            }            
            System.out.println("Your last login was : ");
            System.out.println(line);
        } catch (IOException io) {
            System.out.println("File IO exception" + io.getMessage());
        } finally {                    
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException io) {
                System.out.println("Issue closing the Files" + io.getMessage());
            }
        }
    }

    public static void saveData(String filename, Object value1, Object value2, Object value3, Object value4) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter pw = null;
        Date date = new Date();
        long time = date.getTime();
        Timestamp ts = new Timestamp(time);
        try {
            fw = new FileWriter(filename, true);
            bw = new BufferedWriter(fw);
            pw = new PrintWriter(bw);            
            pw.println((value1) + " " + (value2) + " " + (value3) + " " + (value4) + " ");
            System.out.println("Data Successfully appended into file");
            pw.flush();
        } // print error message if there is one
        catch (IOException io) {
            System.out.println("File IO Exception" + io.getMessage());
        } //close the file
        finally {
            try {
                pw.close();
                bw.close();
                fw.close();
            } //print error message if there is one
            catch (IOException io) {
                System.out.println("Issue closing the File." + io.getMessage());
            }
        }
    }

    public static void saveEarnings(String filename, double value) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter pw = null;
        Date date = new Date();
        long time = date.getTime();
        Timestamp ts = new Timestamp(time);
        try {
            fw = new FileWriter(filename, true);
            bw = new BufferedWriter(fw);
            pw = new PrintWriter(bw);           
            pw.println("DateTime: " + ts + " " + (value));
            System.out.println("Data Successfully appended into file");
            pw.flush();
        } // print error message if there is one
        catch (IOException io) {
            System.out.println("File IO Exception" + io.getMessage());
        } //close the file
        finally {
            try {
                pw.close();
                bw.close();
                fw.close();
            } //print error message if there is one
            catch (IOException io) {
                System.out.println("Issue closing the File." + io.getMessage());
            }
        }
    }

    public void openChecking1() {
        try {
            scan = new Scanner(new File("checking1.txt"));
            System.out.println("it is working");
        } catch (FileNotFoundException e) {
            System.out.println("it is not working");
        }
    }

    public void readChecking1() {
        do {
            checkingDate1 = scan.next();
            if (scan.hasNext()) {
                checkingAmount1 = scan.next();
            }
            if (scan.hasNext()) {
                checkingRate1 = scan.next();
            }
            if (scan.hasNext()) {
                checkingEarnings1 = scan.next();
            }
        } while (scan.hasNext());
        System.out.println(checkingDate1);
        scan.close();
    }

    public void openSavings1() {
        try {
            scan = new Scanner(new File("savings1.txt"));
            System.out.println("it is working");
        } catch (FileNotFoundException e) {
            System.out.println("it is not working");
        }
    }

    public void readSavings1() {
        do {
            savingsDate1 = scan.next();
            if (scan.hasNext()) {
                savingsAmount1 = scan.next();
            }
            if (scan.hasNext()) {
                savingsRate1 = scan.next();
            }
            if (scan.hasNext()) {
                savingsEarnings1 = scan.next();
            }
        } while (scan.hasNext());
        System.out.println(savingsDate1);
        scan.close();
    }
}

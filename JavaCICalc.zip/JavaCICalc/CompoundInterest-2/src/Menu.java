/*
 * Java Swing Compound Interest Calculator
 * Author: Cindy Doan
 * 05/19/2021
 */
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.*;
import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import javax.swing.*;

public class Menu extends JFrame implements ActionListener {

    JFrame main = new JFrame("Earned Interest Accounts");
    JPanel panel;
    JLabel label1 = new JLabel("Interest Earned");
    JLabel label2 = new JLabel("Earnings: $ ");
    JLabel labelnDays = new JLabel(" ");
    JLabel labelAmount = new JLabel(" Starting Balance: $ ");
    JLabel labelRate = new JLabel(" Rate: % ");
    JLabel labelBalance = new JLabel("Ending Balance: $ ");
    JLabel labelPastDate = new JLabel(" Past Date: ");
    JLabel labelNowDate = new JLabel(" Now Date: ");
    JTextField textAmount = new JTextField("");
    JTextField textRate = new JTextField("");
    JTextField textBalance = new JTextField("");
    JTextField textPastDate = new JTextField("");
    JTextField textNowDate = new JTextField("");
    JTextField totEarnings = new JTextField("");
    JRadioButton checkingButton = new JRadioButton("Checking");
    JRadioButton savingsButton = new JRadioButton("Savings");
    JButton EarnedInterest = new JButton("Earnings");
    JButton backButton;
    JButton editAmount = new JButton("Edit");
    JButton editRate = new JButton("Edit");
    JOptionPane alerts = new JOptionPane();
    int popupWidth = 200;
    int popupHeight = 100;
    Account checking = new Account(Double.valueOf(Record.checkingAmount1));
    Account savings = new Account(Double.valueOf("0.01"));
    NumberFormat formatter = new DecimalFormat("#0.00");
    DecimalFormat dc = new DecimalFormat("0.00");
    Record f = new Record();
    public static LocalDate nowDate = LocalDate.now();
    public static long Cdays = 0;
    public static long Sdays = 0;

    public void mainWindow() {
        panel = new JPanel(null);
        main.add(panel);
        label1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 28));
        label1.setHorizontalAlignment(JLabel.CENTER);
        label1.setForeground(Color.BLUE);
        label1.setSize(360, 100);
        label1.setBounds(0, 20, 380, 30);
        JPanel optionPanel = new JPanel();
        optionPanel.setBounds(0, 70, 360, 300);
        //grouping the checking and savings radioButtons
        ButtonGroup buttonGroup = new javax.swing.ButtonGroup();
        buttonGroup.add(checkingButton);
        buttonGroup.add(savingsButton);
        buttonGroup.setSelected(checkingButton.getModel(), true);
        //adds the radiobuttons to the option panel
        optionPanel.add(checkingButton);
        checkingButton.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
        checkingButton.setForeground(Color.BLUE);
        checkingButton.setBounds(0, 20, 380, 100);
        optionPanel.add(savingsButton);
        savingsButton.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
        savingsButton.setForeground(Color.BLUE);
        savingsButton.setBounds(0, 20, 380, 100);
        labelAmount.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        labelAmount.setBounds(30, 120, 220, 30);
        textAmount.setBounds(160, 120, 110, 30);
        labelRate.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        labelRate.setBounds(100, 160, 220, 30);
        textRate.setBounds(160, 160, 110, 30);
        label2.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        label2.setBounds(80, 200, 150, 30);
        totEarnings.setBounds(160, 200, 80, 30);
        labelnDays.setFont(new Font("Microsoft YaHei UI", Font.BOLD | Font.ITALIC, 12));
        labelnDays.setForeground(Color.BLUE);
        labelnDays.setBounds(240, 200, 80, 30);
        labelBalance.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        labelBalance.setBounds(40, 240, 220, 30);
        textBalance.setBounds(160, 240, 110, 30);
        labelPastDate.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        labelPastDate.setBounds(80, 280, 150, 30);
        textPastDate.setBounds(160, 280, 110, 30);
        labelNowDate.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        labelNowDate.setBounds(80, 320, 150, 30);
        textNowDate.setBounds(160, 320, 110, 30);
        EarnedInterest.setBounds(160, 360, 110, 30);
        EarnedInterest.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
        backButton = new JButton("To Calculator");
        backButton.setFont(new Font("Microsoft YaHei UI", Font.BOLD | Font.ITALIC, 12));
        backButton.setForeground(Color.GRAY);
        backButton.setBounds(30, 410, 120, 20);
        editAmount.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 11));
        editAmount.setForeground(Color.RED);
        editAmount.setBounds(280, 240, 60, 20);
        editRate.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 11));
        editRate.setForeground(Color.RED);
        editRate.setBounds(280, 160, 60, 20);

        panel.add(label1);
        panel.add(backButton);
        panel.add(labelAmount);
        panel.add(textAmount);
        panel.add(labelRate);
        panel.add(textRate);
        panel.add(label2);
        panel.add(totEarnings);
        panel.add(labelnDays);
        panel.add(labelBalance);
        panel.add(textBalance);
        panel.add(textNowDate);
        panel.add(labelPastDate);
        panel.add(textPastDate);
        panel.add(labelNowDate);
        panel.add(EarnedInterest);
        panel.add(editAmount);
        panel.add(editRate);
        panel.add(optionPanel);
        main.setSize(400, 500);
        main.setLocationRelativeTo(null);
        main.setVisible(true);
        main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        EarnedInterest.addActionListener(this);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent a) {
                CI frame = new CI();
                frame.plainWindow();
                main.setVisible(false);
            }
        });

        editRate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent a) {
                try {
                    //check for numbers decimals
                    if (textRate.getText().matches("^\\d*\\.\\d+|\\d+\\.\\d*$") == false) {
                        setPane(popupWidth, popupHeight, "Exception", "Please enter a number with decimal places.");
                    } else {
                        //gets the user input from the textfield
                        double interestRate = Double.parseDouble(textRate.getText());
                        //if checking is selected the deposit is made to checking and message for success
                        if (checkingButton.isSelected()) {
                            //gets the user input from the textfield
                            //  double interestRate = Double.parseDouble(textField2.getText());
                            checking.updateRate(interestRate);
                            f.openChecking1();
                            f.readChecking1();
                            double nRate = checking.getRate();
                            String formatRate = dc.format(nRate);
                            textBalance.setText(Record.checkingAmount1);
                            double cbal = Double.parseDouble(textBalance.getText());
                            checking.updateBalance(cbal);
                            String formatBal = dc.format(cbal);
                            totEarnings.setText(Record.checkingEarnings1);
                            double cEarnings = Double.parseDouble(textBalance.getText());
                            checking.updateBalance(cEarnings);
                            String formatEarn = dc.format(cEarnings);
                            f.saveData("Checking1.txt", nowDate, formatBal, formatRate, formatEarn);
                            textBalance.setText(Record.checkingAmount1);
                            textAmount.setText("");
                            textRate.setText(formatRate);
                            textNowDate.setText("");
                            textPastDate.setText("");
                            totEarnings.setText("");
                        } //if savings is selected the deposit is made to savings and inidcates successful
                        else if (savingsButton.isSelected()) {

                        } //if neither are selected the user is prompted to select an account
                        else {
                            setPane(popupWidth, popupHeight, "Exception", "Please select an account");
                        }
                    }
                } //tells the user they must enter a number
                catch (NumberFormatException b) {
                    setPane(popupWidth, popupHeight, "Exception", "Please enter a number with decimal places.");
                }
            }
        });

        editAmount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent a) {
                try {
                    //check for numbers decimals
                    if (textBalance.getText().matches("^\\d*\\.\\d+|\\d+\\.\\d*$") == false) {
                        setPane(popupWidth, popupHeight, "Exception", "Please enter a number with decimal places.");
                    } else {
                        //gets the user input from the textfield
                        double cBal = Double.parseDouble(textBalance.getText());
                        //if checking is selected the deposit is made to checking and message for success
                        if (checkingButton.isSelected()) {
                            checking.updateBalance(cBal);
                            f.openChecking1();
                            f.readChecking1();
                            String formatBal = dc.format(cBal);
                            textRate.setText(Record.checkingRate1);
                            double cRate = Double.parseDouble(textRate.getText());
                            checking.updateRate(cRate);
                            String formatRate = dc.format(cRate);
                            totEarnings.setText(Record.checkingEarnings1);
                            double cEarnings = Double.parseDouble(textBalance.getText());
                            checking.updateBalance(cEarnings);
                            String formatEarn = dc.format(cEarnings);
                            textAmount.setText("");
                            textNowDate.setText("");
                            textPastDate.setText("");
                            totEarnings.setText("");
                            f.saveData("Checking1.txt", nowDate, formatBal, formatRate, formatEarn);
                        } //if savings is selected the deposit is made to savings and inidcates successful
                        else if (savingsButton.isSelected()) {

                        } //if neither are selected the user is prompted to select an account
                        else {
                            setPane(popupWidth, popupHeight, "Exception", "Please select an account");
                        }
                    }
                } //tells the user they must enter a number
                catch (NumberFormatException b) {
                    setPane(popupWidth, popupHeight, "Exception", "Please enter a number with decimal places.");
                }
            }
        });
    }

    private void setPane(int width, int height, String title, String dialog) {
        alerts.setSize(width, height);
        alerts.showMessageDialog(main, dialog, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public void actionPerformed(ActionEvent e) {        
            if (checkingButton.isSelected()) {
                String response = "for " + Cdays + " days ";
                labelnDays.setText(response);
                f.openChecking1();
                f.readChecking1();
                textRate.setText(Record.checkingRate1);
                textBalance.setText(Record.checkingAmount1);
                textPastDate.setText(Record.firstWord1);
                textNowDate.setText(Record.checkingDate1);
                totEarnings.setText(Record.checkingEarnings1);
                textAmount.setText(Record.firstBal1);
            } else if (savingsButton.isSelected()) {
                String response = "for " + Sdays + " days ";
                labelnDays.setText(response);
                f.openSavings1();
                f.readSavings1();
                textRate.setText(Record.savingsRate1);
                textBalance.setText(Record.savingsAmount1);
                textPastDate.setText(Record.firstWord2);
                textNowDate.setText(Record.savingsDate1);
                totEarnings.setText(Record.savingsEarnings1);
                textAmount.setText(Record.firstBal2);
            } //if neither are selected the user is prompted to select an account
            else {
                setPane(popupWidth, popupHeight, "Exception", "Please select an account");                
            }     
    }

    public static void main(String[] args) {
        Record f = new Record();
        Record.lastDateCalc1();
        Record.lastDateCalc2();
        Record.lastDateCalc2();
        Record.lastAccessed();
        File file1 = new File("checking1.txt");
        File file2 = new File("savings1.txt");
        if (file1.exists() && file2.exists()) {
            System.out.println("Exists");
        } else {
            System.out.println("Does not Exists");
            f.writeFile("checking1.txt", "2021-05-21 ", "1000.00 ", "12.000 ", "0.00");
            f.writeFile("savings1.txt", "2021-05-21 ", "100000.00 ", "12.000 ", "0.00");
        }
        // open and reads data        
        f.openChecking1();
        f.readChecking1();
        f.openSavings1();
        f.readSavings1();
        f.lastDateCalc1();
        f.lastDateCalc2();
        System.out.println(nowDate);
        LocalDate testC = LocalDate.parse(Record.checkingDate1);
        LocalDate testS = LocalDate.parse(Record.savingsDate1);
        Cdays = ChronoUnit.DAYS.between(testC, nowDate);
        Sdays = ChronoUnit.DAYS.between(testS, nowDate);
        System.out.printf("%s  %s  days between : " + Cdays, Record.checkingDate1, nowDate);
        System.out.println(" ");
        System.out.printf("%s  %s  days between : " + Sdays, Record.savingsDate1, nowDate);
        System.out.println(" ");
        DecimalFormat dc = new DecimalFormat("0.00");
        double rate = Double.parseDouble(Record.checkingRate1);
        double cbal = Double.parseDouble(Record.checkingAmount1);
        double rate2 = Double.parseDouble(Record.savingsRate1);
        double cbal2 = Double.parseDouble(Record.savingsAmount1);

        double totEarnings = 0;
        double totEarnings2 = 0;

        for (int i = 0; i < Cdays; i++) {
            double earnings = cbal * (rate / 100 / 365);
            cbal = cbal + earnings;
            totEarnings += earnings;
            Record.saveEarnings("AutoEarnChecking.txt", earnings);
        }

        for (int i = 0; i < Sdays; i++) {
            double earnings2 = cbal2 * (rate2 / 100 / 365);
            cbal2 = cbal2 + earnings2;
            totEarnings2 += earnings2;
            Record.saveEarnings("AutoEarnSavings.txt", earnings2);
        }

        String formatBal = dc.format(cbal);
        String formatRate = dc.format(rate);
        String formatEarnings = dc.format(totEarnings);
        Record.saveEarnings("AutoEarnChecking.txt", totEarnings);

        Record.saveData("checking1.txt", nowDate, formatBal, formatRate, formatEarnings);

        String formatBal2 = dc.format(cbal2);
        String formatRate2 = dc.format(rate2);
        String formatEarnings2 = dc.format(totEarnings2);
        Record.saveEarnings("AutoEarnSavings.txt", totEarnings2);
        Record.saveData("savings1.txt", nowDate, formatBal2, formatRate2, formatEarnings2);
       

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Menu frame = new Menu();
                    frame.mainWindow();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
